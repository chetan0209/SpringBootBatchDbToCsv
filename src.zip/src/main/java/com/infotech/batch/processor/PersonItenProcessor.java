package com.infotech.batch.processor;

import java.sql.Date;

import org.springframework.batch.item.ItemProcessor;

import com.infotech.batch.model.Person;

public class PersonItenProcessor implements ItemProcessor<Person, Person>{
	static int count=1;
	
	
	
	@Override
	public Person process(Person person) throws Exception {
		
		String msg=checkValidation(person);
		System.out.println("msg value from db "+msg);
		if(msg!=null) {
			person.setStatus("Invalid n");
			System.out.println("Invalid test call 1");
			person.setStatusdesc(msg+" Today's :: ");
		}
		else {
			person.setStatus("Valid data");

			System.out.println("valid test call second");
			person.setStatusdesc("Valid record's test");
		}
		
			return person;
	}
	
	/*
	 * @Override public Person process(Person person) throws Exception {
	 * 
	 * String msg=checkValidation(person);
	 * 
	 * if(msg!=null) {
	 * 
	 * } System.out.println("Count :: "+count+"FN :: "+person.getFirst_name());
	 * if(person.getFirst_name().equals("PETER")) { person.setFirst_name("Chetan1");
	 * 
	 * System.out.println("Count :: "+count+"FN :: "+person.getFirst_name());
	 * 
	 * } // System.out.println("Count :: "+count+"FN :: "+person.getFirstName());
	 * 
	 * count++; return person; }
	 */

	private String checkValidation(Person person) {
		StringBuffer sb=new StringBuffer();
		String s=null;
		if(person.getFirst_name()==null||person.getFirst_name().length()==0) {
			sb.append("Firstname is null !");
			System.out.println("First name is not there");
		}
		if(person.getLast_name()==null||person.getLast_name().length()==0) {
			sb.append("Last Name is null ");

			System.out.println("Last name is not there");
		}
		if(sb.length()==0) {
			return s;
			
		}
		else {
			s=sb.toString();
			return s;
		}
		//return s;
	}
}
