package com.infotech.batch.config;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.infotech.batch.model.Person;

public class PersonRowMapper implements RowMapper<Person> {

	@Override
	public Person mapRow(ResultSet rs, int rowNum) throws SQLException {
		Person person = new Person();
		person.setPerson_id(rs.getInt("person_id"));
		person.setFirst_name(rs.getString("first_name"));
		person.setLast_name(rs.getString("last_name"));
		person.setEmail(rs.getString("email"));
		person.setAge(rs.getInt("age"));
		person.setStatus(rs.getString("status"));
		person.setStatusdesc(rs.getString("statusdesc"));
		return person;
	}

}
